import React,{ createContext} from 'react'
const AuthApi=createContext();
export default AuthApi;